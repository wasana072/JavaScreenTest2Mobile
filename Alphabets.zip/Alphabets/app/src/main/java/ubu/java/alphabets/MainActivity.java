package ubu.java.alphabets;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Alphabet a,b,c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        a = new Alphabet();
        a.setaChar('a');
        a.setImage((int)R.drawable.a);
        a.setPhonetic("ei");

        b = new Alphabet();
        b.setaChar('b');
        b.setImage((int)R.drawable.b);
        b.setPhonetic("bi:");

        c = new Alphabet();
        c.setaChar('c');
        c.setImage((int)R.drawable.c);
        c.setPhonetic("si:");

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);

        scrollView.addView(linearLayout);

        final ImageView imageView1 = new ImageView(this);
        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params1.setMargins(0, 30, 0, 30);
        params1.gravity = Gravity.CENTER;
        imageView1.setLayoutParams(params1);
        imageView1.setImageResource(R.drawable.a);
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ShowAlphabet.class);
                intent.putExtra("alphabet", a);
                startActivity(intent);
            }
        });
        linearLayout.addView(imageView1);

        ImageView imageView2 = new ImageView(this);
        LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params2.setMargins(0, 0, 0, 30);
        params2.gravity = Gravity.CENTER;
        imageView2.setLayoutParams(params2);
        imageView2.setImageResource(R.drawable.b);
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ShowAlphabet.class);
                intent.putExtra("alphabet", b);
                startActivity(intent);
            }
        });
        linearLayout.addView(imageView2);

        ImageView imageView3 = new ImageView(this);
        LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params3.setMargins(0, 0, 0, 30);
        params3.gravity = Gravity.CENTER;
        imageView3.setLayoutParams(params3);
        imageView3.setImageResource(R.drawable.c);
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ShowAlphabet.class);
                intent.putExtra("alphabet", c);
                startActivity(intent);
            }
        });
        linearLayout.addView(imageView3);



        // show alphabets on linearlayout
        //
        LinearLayout linearLayout1 = findViewById(R.id.rootContainer);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }

    }
}
